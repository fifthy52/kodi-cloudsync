__version__ = "2.1.1.dev0"


class MQTTException(Exception):
    pass
