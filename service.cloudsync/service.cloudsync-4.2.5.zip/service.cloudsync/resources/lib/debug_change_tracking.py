"""
Debug script to examine file change tracking data
"""

import sys
import os
import xbmc
import xbmcaddon
import xbmcvfs

# Add the lib directory to the path
addon_path = xbmcaddon.Addon('service.cloudsync').getAddonInfo('path')
lib_path = xbmcvfs.translatePath(os.path.join(addon_path, 'resources', 'lib'))
sys.path.append(lib_path)

from file_change_tracker import FileChangeTracker


def debug_change_tracking():
    """Debug file change tracking system."""
    xbmc.log("[CloudSync] Starting change tracking debug", xbmc.LOGINFO)

    tracker = FileChangeTracker()
    stats = tracker.get_tracking_stats()

    xbmc.log(f"[CloudSync] Tracking database: {stats['tracking_db_path']}", xbmc.LOGINFO)
    xbmc.log(f"[CloudSync] Total tracked files: {stats['total_files']}", xbmc.LOGINFO)

    for file_type, count in stats['file_types'].items():
        xbmc.log(f"[CloudSync] {file_type}: {count} files", xbmc.LOGINFO)

    # Show some tracked files examples
    if tracker.tracking_data:
        xbmc.log("[CloudSync] Sample tracked files:", xbmc.LOGINFO)
        for i, (file_path, info) in enumerate(list(tracker.tracking_data.items())[:5]):
            last_sync = info.get('last_sync', 0)
            import time
            last_sync_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(last_sync)) if last_sync else 'never'

            xbmc.log(f"[CloudSync]   {i+1}. {file_path}", xbmc.LOGINFO)
            xbmc.log(f"[CloudSync]      Type: {info.get('file_type', 'unknown')}", xbmc.LOGINFO)
            xbmc.log(f"[CloudSync]      Size: {info.get('size', 0)} bytes", xbmc.LOGINFO)
            xbmc.log(f"[CloudSync]      Last sync: {last_sync_str}", xbmc.LOGINFO)
            xbmc.log(f"[CloudSync]      Hash: {info.get('hash', 'none')[:16]}...", xbmc.LOGINFO)

        if len(tracker.tracking_data) > 5:
            xbmc.log(f"[CloudSync] ... and {len(tracker.tracking_data) - 5} more files", xbmc.LOGINFO)

    # Test change detection for some common files
    test_files = [
        ("special://profile/favourites.xml", "favorites"),
        ("special://profile/sources.xml", "userdata/sources.xml"),
        ("special://profile/addon_data/skin.estuary/settings.xml", "addon_data/skin.estuary/settings.xml")
    ]

    for special_path, file_type in test_files:
        try:
            file_path = xbmcvfs.translatePath(special_path)
            if os.path.exists(file_path):
                has_changed, reason = tracker.has_file_changed(file_path, file_type)
                xbmc.log(f"[CloudSync] {file_type}: {'CHANGED' if has_changed else 'no changes'} ({reason})", xbmc.LOGINFO)
            else:
                xbmc.log(f"[CloudSync] {file_type}: file not found at {file_path}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[CloudSync] Error testing {file_type}: {e}", xbmc.LOGERROR)

    xbmc.log("[CloudSync] Change tracking debug completed", xbmc.LOGINFO)


if __name__ == '__main__':
    debug_change_tracking()