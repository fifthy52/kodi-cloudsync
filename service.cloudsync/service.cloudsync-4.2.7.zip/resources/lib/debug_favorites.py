import sys
import os
import json
import xbmc
import xbmcaddon
import xbmcgui

# Add current directory to path
current_dir = os.path.dirname(__file__)
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)


def debug_favorites():
    """Debug favorites functionality."""
    try:
        dialog = xbmcgui.Dialog()
        
        # Test getting favorites
        request = {
            "jsonrpc": "2.0",
            "method": "Favourites.GetFavourites",
            "params": {},
            "id": 1
        }
        
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        
        lines = ["=== FAVORITES DEBUG ===", ""]
        
        if 'result' in response:
            if 'favourites' in response['result']:
                favorites = response['result']['favourites']
                lines.append(f"Found {len(favorites)} favorites:")
                lines.append("")
                
                for i, fav in enumerate(favorites[:5]):  # Show first 5
                    lines.append(f"{i+1}. Title: {fav.get('title', 'No title')}")
                    lines.append(f"   Type: {fav.get('type', 'No type')}")
                    lines.append(f"   Path: {fav.get('path', 'No path')[:50]}...")
                    lines.append("")
                
                if len(favorites) > 5:
                    lines.append(f"... and {len(favorites) - 5} more")
            else:
                lines.append("No 'favourites' key in result")
        else:
            lines.append("ERROR in response:")
            lines.append(str(response))
        
        lines.append("")
        lines.append("=== RAW RESPONSE ===")
        lines.append(json.dumps(response, indent=2))
        
        dialog.textviewer("Favorites Debug", "\n".join(lines))
        
    except Exception as e:
        xbmcgui.Dialog().ok("Debug Error", f"Error: {str(e)}")


if __name__ == "__main__":
    debug_favorites()