"""
Debug script to examine actual favorites data structure
"""

import sys
import os
import xbmc
import xbmcaddon
import xbmcvfs

# Add the lib directory to the path
addon_path = xbmcaddon.Addon('service.cloudsync').getAddonInfo('path')
lib_path = xbmcvfs.translatePath(os.path.join(addon_path, 'resources', 'lib'))
sys.path.append(lib_path)

from kodi_utils import get_favorites


def debug_favorites_data():
    """Debug actual favorites data structure"""
    xbmc.log("[CloudSync] Starting favorites data debug", xbmc.LOGINFO)

    favorites = get_favorites()
    xbmc.log(f"[CloudSync] Total favorites: {len(favorites)}", xbmc.LOGINFO)

    for i, fav in enumerate(favorites):
        xbmc.log(f"[CloudSync] Favorite {i+1}:", xbmc.LOGINFO)
        for key, value in fav.items():
            xbmc.log(f"[CloudSync]   {key}: {value}", xbmc.LOGINFO)
        xbmc.log("[CloudSync] ---", xbmc.LOGINFO)

    # Try to understand the structure for AddFavourite
    if favorites:
        first_fav = favorites[0]
        xbmc.log("[CloudSync] Testing AddFavourite structure:", xbmc.LOGINFO)
        xbmc.log(f"[CloudSync] Title: {first_fav.get('title', '')}", xbmc.LOGINFO)
        xbmc.log(f"[CloudSync] Path: {first_fav.get('path', '')}", xbmc.LOGINFO)
        xbmc.log(f"[CloudSync] Type: {first_fav.get('type', '')}", xbmc.LOGINFO)
        xbmc.log(f"[CloudSync] Window: {first_fav.get('window', '')}", xbmc.LOGINFO)
        xbmc.log(f"[CloudSync] WindowParameter: {first_fav.get('windowparameter', '')}", xbmc.LOGINFO)

    xbmc.log("[CloudSync] Favorites data debug completed", xbmc.LOGINFO)


if __name__ == '__main__':
    debug_favorites_data()