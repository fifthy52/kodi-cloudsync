"""
Test script for favorites functionality
"""

import sys
import os
import xbmc
import xbmcaddon
import xbmcvfs

# Add the lib directory to the path
addon_path = xbmcaddon.Addon('service.cloudsync').getAddonInfo('path')
lib_path = xbmcvfs.translatePath(os.path.join(addon_path, 'resources', 'lib'))
sys.path.append(lib_path)

from kodi_utils import get_favorites, clear_favorites, add_favorite


def test_favorites():
    """Test favorites functionality step by step"""

    xbmc.log("[CloudSync] Starting favorites test", xbmc.LOGINFO)

    # Step 1: Get current favorites
    xbmc.log("[CloudSync] Step 1: Getting current favorites", xbmc.LOGINFO)
    favorites = get_favorites()
    xbmc.log(f"[CloudSync] Found {len(favorites)} favorites", xbmc.LOGINFO)

    for i, fav in enumerate(favorites):
        xbmc.log(f"[CloudSync] Favorite {i+1}: {fav}", xbmc.LOGINFO)

    # Step 2: Test adding a favorite
    xbmc.log("[CloudSync] Step 2: Adding test favorite", xbmc.LOGINFO)
    success = add_favorite(
        title="CloudSync Test",
        path="ActivateWindow(10025)",
        fav_type="window"
    )
    xbmc.log(f"[CloudSync] Add favorite result: {success}", xbmc.LOGINFO)

    # Step 3: Get favorites again
    xbmc.log("[CloudSync] Step 3: Getting favorites after add", xbmc.LOGINFO)
    favorites_after = get_favorites()
    xbmc.log(f"[CloudSync] Found {len(favorites_after)} favorites after add", xbmc.LOGINFO)

    # Step 4: Test clearing favorites
    if len(favorites_after) > 0:
        xbmc.log("[CloudSync] Step 4: Clearing all favorites", xbmc.LOGINFO)
        clear_result = clear_favorites()
        xbmc.log(f"[CloudSync] Clear favorites result: {clear_result}", xbmc.LOGINFO)

        # Step 5: Check if cleared
        xbmc.log("[CloudSync] Step 5: Checking if favorites cleared", xbmc.LOGINFO)
        favorites_cleared = get_favorites()
        xbmc.log(f"[CloudSync] Found {len(favorites_cleared)} favorites after clear", xbmc.LOGINFO)

        # Step 6: Restore original favorites
        xbmc.log("[CloudSync] Step 6: Restoring original favorites", xbmc.LOGINFO)
        for fav in favorites:
            success = add_favorite(
                title=fav.get('title', ''),
                path=fav.get('path', ''),
                fav_type=fav.get('type', 'window'),
                thumbnail=fav.get('thumbnail', ''),
                windowparameter=fav.get('windowparameter', '')
            )
            xbmc.log(f"[CloudSync] Restored: {fav.get('title', '')} - {success}", xbmc.LOGINFO)

    xbmc.log("[CloudSync] Favorites test completed", xbmc.LOGINFO)


if __name__ == '__main__':
    test_favorites()